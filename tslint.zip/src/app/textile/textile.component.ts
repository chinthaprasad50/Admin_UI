import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-textile',
  templateUrl: './textile.component.html',
  styleUrls: ['./textile.component.css']
})
export class TextileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicledata',
  templateUrl: './vehicledata.component.html',
  styleUrls: ['./vehicledata.component.css']
})
export class VehicledataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manfacturing',
  templateUrl: './manfacturing.component.html',
  styleUrls: ['./manfacturing.component.css']
})
export class ManfacturingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
